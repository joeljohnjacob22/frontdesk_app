import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { and, eq, isNull, inArray, sql } from 'drizzle-orm';
import * as s from '../db/schema.js';

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
const db = drizzle(pool, { schema: s });
const sha = (x) => crypto.createHash('sha256').update(x).digest();
// Drizzle wraps driver errors: the Postgres message is on err.cause
const rejectsPg = (p, re) => assert.rejects(p, (e) => re.test(e.cause?.message ?? e.message));
let ticketId, tok = crypto.randomBytes(16).toString('hex');

test.before(async () => {
  await db.insert(s.users).values([{ name: 'A1', email: 'a1@x', passwordHash: 'h' }, { name: 'A2', email: 'a2@x', passwordHash: 'h' }]);
  const [c] = await db.insert(s.customers).values({ name: 'Cust', email: 'c@x' }).returning();
  const [t] = await db.insert(s.tickets).values({ customerId: c.id, subject: 'Help', accessTokenHash: sha(tok) }).returning();
  ticketId = t.id;
  const [u1] = await db.select().from(s.users).where(eq(s.users.email, 'a1@x'));
  await db.insert(s.messages).values([
    { ticketId, kind: 'note', authorType: 'staff', authorUserId: u1.id, body: 'SECRET-SENTINEL' },
    { ticketId, kind: 'public', authorType: 'customer', authorCustomerId: c.id, body: 'hello' },
  ]);
});
test.after(() => pool.end());

test('claim race: exactly one winner', async () => {
  const users = await db.select().from(s.users);
  const claim = (uid) => db.update(s.tickets)
    .set({ assigneeId: uid, claimedAt: sql`now()`, status: sql`CASE WHEN ${s.tickets.status} = 'new' THEN 'open'::ticket_status ELSE ${s.tickets.status} END` })
    .where(and(eq(s.tickets.id, ticketId), isNull(s.tickets.assigneeId), inArray(s.tickets.status, ['new', 'open', 'waiting_on_customer'])))
    .returning({ id: s.tickets.id });
  const results = await Promise.all(users.map((u) => claim(u.id)));
  assert.equal(results.filter((r) => r.length === 1).length, 1);
});

test('customer view never shows notes', async () => {
  const rows = await db.select().from(s.customerMessages).where(eq(s.customerMessages.accessTokenHash, sha(tok)));
  assert.equal(rows.length, 1);
  assert.ok(!JSON.stringify(rows).includes('SECRET-SENTINEL'));
});

test('append-only + chain', async () => {
  await rejectsPg(db.update(s.messages).set({ body: 'x' }), /append-only/);
  await Promise.all([...Array(8)].map((_, i) =>
    db.insert(s.ticketEvents).values({ ticketId, type: 'status_changed', actorType: 'system', payload: { i }, hash: Buffer.alloc(0) })));
  await rejectsPg(db.delete(s.ticketEvents), /append-only/);   // rows exist now, so the row trigger fires
  const r = await db.execute(sql`SELECT count(*)::int n, bool_and(ok) ok, max(chain_seq) mx FROM verify_ticket_chain(${ticketId})`);
  assert.deepEqual(r.rows[0], { n: 8, ok: true, mx: 8 });
});

test('check constraints bite', async () => {
  await rejectsPg(db.update(s.tickets).set({ status: 'waiting_on_customer' }).where(eq(s.tickets.id, ticketId)), /tickets_waiting_fields/);
});
